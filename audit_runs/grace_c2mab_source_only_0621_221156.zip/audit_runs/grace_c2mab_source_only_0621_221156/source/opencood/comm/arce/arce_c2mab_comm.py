"""
PDF-aligned DC2MAB-ARCE communication controller.

Modified for the new communication setting:

1. Channel states:
   Good / Medium / Bad.

2. Packet loss:
   packet_i independently follows:
       receive_i ~ Bernoulli(1 - PLR_t)
   with:
       Good   PLR = 0.05
       Medium PLR = 0.20
       Bad    PLR = 0.35

3. Delay:
       Good   -> 10 ms, current frame
       Medium -> 50 ms, current frame
       Bad    -> 100 ms, previous frame

4. Transition matrix:
       Good   -> [0.85, 0.13, 0.02]
       Medium -> [0.10, 0.80, 0.10]
       Bad    -> [0.03, 0.17, 0.80]

5. Bandwidth budget:
   Final setting supports channel_profiles + global_sum_link.
   Each collaborator obtains a state-dependent link budget from its current
   Markov channel state, and the ego-side oracle uses their sum as the
   global super-arm budget.

6. Packetization cost model:
   Quantize first, then flatten Q(F) into a byte stream.
   Split by fixed packet size:
       Lp = 1024 bytes
       N = ceil(|v| / Lp)

7. FEC / redundancy:
   Keep rho in the action space.
   For cost estimation:
       parity_packets = ceil(source_packets * rho)
       encoded_packets = source_packets + parity_packets
       encoded_bytes = encoded_packets * Lp
   The selected PDF action is converted to ARCEAction and passed to
   ARCEFixedComm through action_override.
"""

from __future__ import annotations

import copy
import math
from typing import Any, Dict, List, Optional, Sequence, Tuple

import torch

from opencood.comm.arce.arce_fixed_comm import ARCEFixedComm
from opencood.comm.arce.policies.action_space import (
    PDFARCEAction,
    build_pdf_action_space,
    raw_feature_bytes_fp32,
    budget_bytes_from_bandwidth,
)
from opencood.comm.arce.policies.context_builder import PDFContextBuilder
from opencood.comm.arce.policies.discounted_linucb import DiscountedLinUCB
from opencood.comm.arce.policies.ego_greedy_oracle import (
    CAVProposal,
    EgoGreedyKnapsackOracle,
)
from opencood.comm.arce.policies.reward import (
    RewardBuffer,
    effective_receive_quality,
)
from opencood.comm.arce.policies.ap_gain_reward import c2mab_ap_gain_reward
from opencood.comm.arce.policies.action_adapter import normalize_runtime_action
from opencood.comm.arce.c2mab_local_confidence import get_cav_confidence


from opencood.comm.arce.c2mab_common import (
    CHANNEL_STATE_ID_TO_NAME,
    DEFAULT_CHANNEL_PROFILES,
    QUANT_RATIO_TO_FP32,
    extract_arce_cfg as _extract_arce_cfg,
    as_list_record_len as _as_list_record_len,
    safe_get_nested as _safe_get_nested,
    profile_scalar as _profile_scalar,
    normalize_state_name as _normalize_state_name,
)

from opencood.comm.arce.c2mab_complementarity import (
    mask_to_bool_2d,
    mask_to_float_2d,
    mask_complementarity,
    confidence_advantage_complementarity,
)


class ARCEC2MABComm:
    """
    DC2MAB-ARCE communication controller.

    This class is the policy/scheduling layer.
    The actual low-level packetization, quantization, FEC, loss, delay,
    and reconstruction are executed by ARCEFixedComm.
    """

    def __init__(self, cfg: Optional[Dict[str, Any]] = None):
        self.full_cfg = cfg or {}
        self.arce_cfg = _extract_arce_cfg(cfg or {})

        # ------------------------------------------------------------------
        # Low-level executor config
        # ------------------------------------------------------------------
        executor_cfg = copy.deepcopy(cfg)

        if isinstance(executor_cfg, dict):
            if isinstance(executor_cfg.get("arce", None), dict):
                executor_arce_cfg = copy.deepcopy(executor_cfg["arce"])
            else:
                executor_arce_cfg = copy.deepcopy(self.arce_cfg)

            # C2MAB chooses per-link action.
            # The executor itself should run in fixed mode and accept action_override.
            executor_arce_cfg["mode"] = "fixed"
            executor_arce_cfg["policy"] = "fixed"

            # Neutral base quantization.
            # Actual mode is selected through action_override.
            quant_cfg = executor_arce_cfg.get("quantization", None)
            if not isinstance(quant_cfg, dict):
                quant_cfg = {}
            quant_cfg.setdefault("mode", "fp32")
            executor_arce_cfg["quantization"] = quant_cfg

            # New packetization.
            packetizer_cfg = executor_arce_cfg.get("packetizer", None)
            if not isinstance(packetizer_cfg, dict):
                packetizer_cfg = {}
            packetizer_cfg["mode"] = "byte_stream"
            packetizer_cfg.setdefault("packet_size_bytes", 1024)
            executor_arce_cfg["packetizer"] = packetizer_cfg

            # New Bernoulli loss + fixed delay.
            channel_cfg = executor_arce_cfg.get("channel", None)
            if not isinstance(channel_cfg, dict):
                channel_cfg = {}

            # The low-level ChannelManager can stay fixed because C2MAB passes
            # channel_state explicitly at runtime.
            channel_cfg["mode"] = "fixed"
            channel_cfg.setdefault("fixed_state", "medium")
            channel_cfg.setdefault("state_source", "dataset_link_markov_override")
            channel_cfg["loss_model"] = "bernoulli"
            channel_cfg["bernoulli_loss_rates"] = {
                "good": 0.05,
                "medium": 0.20,
                "bad": 0.35,
                **copy.deepcopy(channel_cfg.get("bernoulli_loss_rates", {}) or {}),
            }
            channel_cfg["latency_model"] = "fixed_state_delay"
            channel_cfg["fixed_delay_ms"] = {
                "good": 10.0,
                "medium": 50.0,
                "bad": 100.0,
                **copy.deepcopy(channel_cfg.get("fixed_delay_ms", {}) or {}),
            }
            channel_cfg["jitter_ms"] = {
                "good": [0.0, 0.0],
                "medium": [0.0, 0.0],
                "bad": [0.0, 0.0],
            }
            executor_arce_cfg["channel"] = channel_cfg

            # Bad-state previous-frame policy.
            delay_cfg = executor_arce_cfg.get("delay", None)
            if not isinstance(delay_cfg, dict):
                delay_cfg = {}
            delay_cfg["policy_by_state"] = {
                "good": "current",
                "medium": "current",
                "bad": "previous_frame",
                **copy.deepcopy(delay_cfg.get("policy_by_state", {}) or {}),
            }
            executor_arce_cfg["delay"] = delay_cfg

            # Keep FEC / redundancy enabled.
            # Do not force fec.type = none.
            fec_cfg = executor_arce_cfg.get("fec", None)
            if not isinstance(fec_cfg, dict):
                fec_cfg = {}
            fec_cfg.setdefault("enabled", True)
            fec_cfg.setdefault("type", "action")
            fec_cfg.setdefault("default_type", "raptor_sim")
            executor_arce_cfg["fec"] = fec_cfg

            redundancy_cfg = executor_arce_cfg.get("redundancy", None)
            if not isinstance(redundancy_cfg, dict):
                redundancy_cfg = {}
            redundancy_cfg.setdefault("enabled", True)
            executor_arce_cfg["redundancy"] = redundancy_cfg

            # Old patch selection should not be used as the formal packetization.
            patch_cfg = executor_arce_cfg.get("patch_selection", None)
            if not isinstance(patch_cfg, dict):
                patch_cfg = {}
            patch_cfg["enabled"] = False
            executor_arce_cfg["patch_selection"] = patch_cfg

            executor_cfg["arce"] = executor_arce_cfg
            executor_cfg["mode"] = "fixed"
            executor_cfg["policy"] = "fixed"
            executor_cfg["quantization"] = executor_arce_cfg["quantization"]
            executor_cfg["packetizer"] = executor_arce_cfg["packetizer"]
            executor_cfg["channel"] = executor_arce_cfg["channel"]
            executor_cfg["delay"] = executor_arce_cfg["delay"]
            executor_cfg["fec"] = executor_arce_cfg["fec"]
            executor_cfg["redundancy"] = executor_arce_cfg["redundancy"]
        else:
            executor_cfg = {
                "mode": "fixed",
                "policy": "fixed",
                "arce": {
                    **copy.deepcopy(self.arce_cfg),
                    "mode": "fixed",
                    "policy": "fixed",
                    "packetizer": {
                        "mode": "byte_stream",
                        "packet_size_bytes": 1024,
                    },
                    "channel": {
                        "mode": "fixed",
                        "fixed_state": "medium",
                        "loss_model": "bernoulli",
                        "bernoulli_loss_rates": {
                            "good": 0.05,
                            "medium": 0.20,
                            "bad": 0.35,
                        },
                        "latency_model": "fixed_state_delay",
                        "fixed_delay_ms": {
                            "good": 10.0,
                            "medium": 50.0,
                            "bad": 100.0,
                        },
                    },
                    "delay": {
                        "policy_by_state": {
                            "good": "current",
                            "medium": "current",
                            "bad": "previous_frame",
                        }
                    },
                    "fec": {
                        "enabled": True,
                        "type": "action",
                        "default_type": "raptor_sim",
                    },
                    "redundancy": {
                        "enabled": True,
                    },
                    "patch_selection": {
                        "enabled": False,
                    },
                },
            }

        self.executor = ARCEFixedComm(executor_cfg)

        # ------------------------------------------------------------------
        # Action space
        # ------------------------------------------------------------------
        action_cfg = self.arce_cfg.get("action_space", {})
        self.actions = build_pdf_action_space(
            fec_mode=action_cfg.get(
                "fec_main",
                action_cfg.get("fec_mode", "raptor_sim"),
            ),
            send_values=action_cfg.get("send_values", action_cfg.get("send", (0, 1))),
            quant_modes=action_cfg.get(
                "quant_modes",
                action_cfg.get("quant", ("fp32", "fp16", "int8", "int4")),
            ),
            redundancy_ratios=action_cfg.get(
                "redundancy_ratios",
                action_cfg.get("rho", (0.0, 0.25, 0.5)),
            ),
            cache_values=action_cfg.get("cache_values", action_cfg.get("cache", (0, 1))),
            xor_group_size=int(action_cfg.get("xor_group_size", 4)),
            decode_overhead=float(action_cfg.get("decode_overhead", 0.0)),
        )
        self.action_ids = [a.action_id for a in self.actions]
        self.action_space = self.actions
        self.no_send_action = next(
            (a for a in self.actions if getattr(a, "is_no_send", False)),
            None,
        )

        # ------------------------------------------------------------------
        # Context / C2MAB
        # ------------------------------------------------------------------
        context_cfg = self.arce_cfg.get("context", {})
        self.include_cav_confidence = bool(context_cfg.get("include_cav_confidence", True))
        self.context_builder = PDFContextBuilder(
            b_max_mbps=float(context_cfg.get("b_max_mbps", 27.0)),
            stale_max_ms=float(
                context_cfg.get(
                    "stale_max_ms",
                    context_cfg.get("deadline_ms", 400.0),
                )
            ),
            confidence_threshold=float(context_cfg.get("confidence_threshold", 0.3)),
            include_cav_confidence=self.include_cav_confidence,
        )

        c2mab_cfg = self.arce_cfg.get("c2mab", {})
        default_context_dim = 7 if bool(self.include_cav_confidence) else 6
        requested_context_dim = int(c2mab_cfg.get("context_dim", default_context_dim))

        # Safety guard:
        # If C_i is enabled, PDFContextBuilder emits 7D context. LinUCB must
        # also be initialized with d=7 even if an old config still says
        # context_dim: 6.
        if bool(self.include_cav_confidence) and requested_context_dim != 7:
            self.context_dim_override_reason = (
                "include_cav_confidence=True requires context_dim=7; "
                "old config requested {}".format(requested_context_dim)
            )
            self.context_dim = 7
        else:
            self.context_dim_override_reason = None
            self.context_dim = requested_context_dim
        self.lambda_reg = float(c2mab_cfg.get("lambda_reg", 1.0))
        self.discount = float(c2mab_cfg.get("discount", 0.97))
        self.beta = float(c2mab_cfg.get("beta", 1.0))

        oracle_cfg = self.arce_cfg.get("ego_oracle", {})
        self.oracle = EgoGreedyKnapsackOracle(
            eps_cost=float(oracle_cfg.get("eps_cost", 1.0)),
            lambda_comp=float(oracle_cfg.get("lambda_comp", 0.5)),
            lambda_red=float(oracle_cfg.get("lambda_red", 0.5)),
            diversity_aware=bool(oracle_cfg.get("diversity_aware", True)),
            cost_alpha=float(oracle_cfg.get("cost_alpha", self.arce_cfg.get("cost_alpha", 0.25))),
            quant_quality_prior=oracle_cfg.get(
                "quant_quality_prior",
                self.arce_cfg.get(
                    "quant_quality_prior",
                    {"fp32": 1.0, "fp16": 0.97, "int8": 0.85, "int4": 0.55},
                ),
            ),
        )

        # Sender-side proposal expansion: each sender/link submits multiple
        # candidate actions to the ego oracle instead of only one. The ego
        # oracle still selects at most one action for each sender.
        self.sender_topk_actions = int(
            oracle_cfg.get(
                "sender_topk_actions",
                self.arce_cfg.get("sender_topk_actions", 12),
            )
        )
        self.sender_topk_actions = max(1, int(self.sender_topk_actions))
        self.sender_force_quant_coverage = bool(
            oracle_cfg.get(
                "sender_force_quant_coverage",
                self.arce_cfg.get("sender_force_quant_coverage", True),
            )
        )
        self.sender_include_low_cost = bool(
            oracle_cfg.get(
                "sender_include_low_cost",
                self.arce_cfg.get("sender_include_low_cost", True),
            )
        )

        # ------------------------------------------------------------------
        # Scheduler / budget
        # ------------------------------------------------------------------
        scheduler_cfg = self.arce_cfg.get("scheduler", {}) or {}
        self.fps = float(scheduler_cfg.get("fps", 10.0))
        self.tx_window_ms = float(
            scheduler_cfg.get(
                "tx_window_ms",
                1000.0 / max(self.fps, 1e-6),
            )
        )

        # New formal budget scope.
        self.budget_scope = str(
            scheduler_cfg.get(
                "budget_scope",
                self.arce_cfg.get("budget_scope", "global_sum_link"),
            )
        ).strip().lower()

        # System total bandwidth, not per-link bandwidth.
        self.system_budget_mbps = float(
            scheduler_cfg.get(
                "system_budget_mbps",
                scheduler_cfg.get(
                    "total_budget_mbps",
                    oracle_cfg.get(
                        "total_budget_mbps",
                        oracle_cfg.get("fallback_total_budget_mbps", 5.0),
                    ),
                ),
            )
        )

        self.total_budget_mbps = self.system_budget_mbps
        self.tau_trans_ms = float(
            oracle_cfg.get(
                "tau_trans_ms",
                oracle_cfg.get("fallback_tx_window_ms", self.tx_window_ms),
            )
        )

        # Packetization cost model.
        packet_cfg = self.arce_cfg.get("packetizer", {}) or {}
        self.packet_size_bytes = int(
            packet_cfg.get("packet_size_bytes", packet_cfg.get("Lp", 1024))
        )
        if self.packet_size_bytes <= 0:
            raise ValueError(
                f"packet_size_bytes must be positive, got {self.packet_size_bytes}."
            )

        self.metadata_bytes_per_packet = int(
            packet_cfg.get(
                "metadata_bytes_per_packet",
                self.arce_cfg.get("patch_selection", {}).get(
                    "metadata_bytes_per_packet",
                    0,
                ),
            )
        )

        # ------------------------------------------------------------------
        # Reward
        # ------------------------------------------------------------------
        reward_cfg = self.arce_cfg.get("reward", {})
        self.reward_alpha_q = float(reward_cfg.get("alpha_q", 0.5))
        self.reward_alpha_c = float(reward_cfg.get("alpha_c", 0.3))
        self.reward_alpha_d = float(reward_cfg.get("alpha_d", 0.2))
        self.reward_alpha_v = float(reward_cfg.get("alpha_v", 1.0))
        self.reward_alpha_m = float(reward_cfg.get("alpha_m", 0.25))
        self.reward_alpha_r = float(reward_cfg.get("alpha_r", 0.20))
        self.reward_alpha_t = float(reward_cfg.get("alpha_t", 0.15))
        self.reward_tau_stale_ms = float(reward_cfg.get("tau_stale_ms", 300.0))
        self.reward_stale_max_ms = float(reward_cfg.get("stale_max_ms", 400.0))

        self.policy_bank: Dict[Tuple[str, str], DiscountedLinUCB] = {}
        self.pending_reward = RewardBuffer()
        self.records: List[Dict[str, Any]] = []
        self.frame_records: Dict[Any, List[Dict[str, Any]]] = {}

        self.last_ego_confidence = float(
            self.arce_cfg.get("initial_ego_confidence", 0.0)
        )
        self.last_cache_quality: Dict[Tuple[str, str], float] = {}

    # ------------------------------------------------------------------
    # Basic helpers
    # ------------------------------------------------------------------

    def _policy_key(self, ego_id: Any, sender_id: Any) -> Tuple[str, str]:
        return (str(ego_id), str(sender_id))

    def get_policy(self, ego_id: Any, sender_id: Any) -> DiscountedLinUCB:
        key = self._policy_key(ego_id, sender_id)
        if key not in self.policy_bank:
            self.policy_bank[key] = DiscountedLinUCB(
                action_ids=self.action_ids,
                context_dim=self.context_dim,
                lambda_reg=self.lambda_reg,
                discount=self.discount,
                beta=self.beta,
            )
        return self.policy_bank[key]

    def _append_record(self, record: Dict[str, Any]) -> None:
        self.records.append(copy.deepcopy(record))
        frame_id = record.get("frame_id", None)
        self.frame_records.setdefault(frame_id, []).append(copy.deepcopy(record))

    def clear_records(self) -> None:
        self.records.clear()
        self.frame_records.clear()
        self.executor.clear_records()

    def reset(self, clear_cache: bool = True, clear_records: bool = True) -> None:
        self.executor.reset(clear_cache=clear_cache, clear_records=clear_records)
        self.policy_bank.clear()
        self.pending_reward = RewardBuffer()
        self.last_cache_quality.clear()
        if clear_records:
            self.clear_records()

    # ------------------------------------------------------------------
    # Channel helpers
    # ------------------------------------------------------------------

    def _channel_profiles_cfg(self) -> Dict[str, Dict[str, Any]]:
        channel_cfg = self.arce_cfg.get("channel", {})
        profiles = channel_cfg.get("profiles", None)

        out = copy.deepcopy(DEFAULT_CHANNEL_PROFILES)

        if isinstance(profiles, dict):
            for state, profile in profiles.items():
                state_l = _normalize_state_name(state)
                if state_l == "ego_or_padding":
                    continue
                if isinstance(profile, dict):
                    merged = copy.deepcopy(out.get(state_l, {}))
                    merged.update(copy.deepcopy(profile))
                    merged.setdefault("state_name", state_l)
                    out[state_l] = merged

        # Force the new PLR / fixed-delay defaults unless explicitly overridden.
        for state_name, plr in (("good", 0.05), ("medium", 0.20), ("bad", 0.35)):
            out[state_name]["loss_rate"] = float(
                out[state_name].get("plr", out[state_name].get("loss_rate", plr))
            )
            out[state_name]["plr"] = float(out[state_name]["loss_rate"])

        for state_name, delay_ms in (("good", 10.0), ("medium", 50.0), ("bad", 100.0)):
            out[state_name]["delay_ms"] = float(
                out[state_name].get("fixed_delay_ms", out[state_name].get("delay_ms", delay_ms))
            )
            out[state_name]["fixed_delay_ms"] = float(out[state_name]["delay_ms"])

        out["good"]["temporal_source"] = "current"
        out["medium"]["temporal_source"] = "current"
        out["bad"]["temporal_source"] = "previous_frame"

        return out

    def _profile_for_state(self, state_name: str) -> Dict[str, Any]:
        state_name = _normalize_state_name(state_name)
        profiles = self._channel_profiles_cfg()
        profile = copy.deepcopy(profiles.get(state_name, profiles.get("medium")))
        profile["state_name"] = state_name
        return profile

    def _extract_channel_state_ids(
        self,
        data_dict: Optional[Dict[str, Any]],
        local_batch_idx: int,
    ) -> Optional[List[int]]:
        if data_dict is None:
            return None

        candidates = [
            _safe_get_nested(data_dict, ["ego", "channel_state_ids"]),
            _safe_get_nested(data_dict, ["channel_state_ids"]),
        ]

        for x in candidates:
            if x is None:
                continue

            if torch.is_tensor(x):
                arr = x.detach().cpu()
                if arr.dim() == 1:
                    return [int(v) for v in arr.tolist()]
                if arr.dim() >= 2:
                    idx = min(int(local_batch_idx), int(arr.shape[0]) - 1)
                    return [int(v) for v in arr[idx].flatten().tolist()]

            if isinstance(x, (list, tuple)):
                if len(x) > 0 and isinstance(x[0], (list, tuple)):
                    idx = min(int(local_batch_idx), len(x) - 1)
                    return [int(v) for v in x[idx]]
                return [int(v) for v in x]

        return None

    def _state_name_for_sender(
        self,
        data_dict: Optional[Dict[str, Any]],
        batch_idx: int,
        sender_local_idx: int,
    ) -> str:
        ids = self._extract_channel_state_ids(data_dict, batch_idx)
        if ids is not None and 0 <= int(sender_local_idx) < len(ids):
            return CHANNEL_STATE_ID_TO_NAME.get(
                int(ids[int(sender_local_idx)]),
                "medium",
            )
        return "medium"

    # ------------------------------------------------------------------
    # Budget helpers
    # ------------------------------------------------------------------

    def _budget_source_scope(self) -> Tuple[str, str]:
        scheduler_cfg = self.arce_cfg.get("scheduler", {}) or {}
        if not isinstance(scheduler_cfg, dict):
            scheduler_cfg = {}

        oracle_cfg = self.arce_cfg.get("ego_oracle", {}) or {}
        if not isinstance(oracle_cfg, dict):
            oracle_cfg = {}

        budget_source = str(
            scheduler_cfg.get(
                "budget_source",
                self.arce_cfg.get(
                    "budget_source",
                    oracle_cfg.get("budget_source", "channel_profiles"),
                ),
            )
        ).strip().lower()

        budget_scope = str(
            scheduler_cfg.get(
                "budget_scope",
                self.arce_cfg.get(
                    "budget_scope",
                    oracle_cfg.get("budget_scope", self.budget_scope),
                ),
            )
        ).strip().lower()

        return budget_source, budget_scope

    def _use_channel_profile_budget(self) -> bool:
        budget_source, budget_scope = self._budget_source_scope()
        return (
            budget_source in ("channel_profiles", "channel_profile", "profiles")
            or budget_scope in ("global_sum_link", "channel_profiles", "channel_profile")
        )

    def _system_budget_bytes(self) -> float:
        return float(
            budget_bytes_from_bandwidth(
                self.system_budget_mbps,
                self.tx_window_ms,
            )
        )

    def _channel_profile_budget_bytes(self, profile: Dict[str, Any]) -> float:
        bandwidth_mbps = _profile_scalar(
            profile.get("bandwidth_mbps", self.system_budget_mbps),
            self.system_budget_mbps,
        )
        return float(
            budget_bytes_from_bandwidth(
                bandwidth_mbps,
                self.tx_window_ms,
            )
        )

    def _per_link_budget_bytes(self, num_collaborators: int) -> float:
        if num_collaborators <= 0:
            return 0.0
        return float(self._system_budget_bytes() / float(num_collaborators))

    def _prepare_link_channel_budget(
        self,
        data_dict: Optional[Dict[str, Any]],
        batch_idx: int,
        sender_idx: int,
        num_collaborators: int,
    ) -> Tuple[str, Dict[str, Any], float]:
        """
        Resolve link state/profile/frame budget for one sender.

        Final setting:
            scheduler.budget_source = channel_profiles
            scheduler.budget_scope  = global_sum_link

        Under this setting, each link first obtains its state-dependent
        channel budget:
            good   -> 27 Mbps
            medium -> 5 Mbps
            bad    -> 1 Mbps

        The ego-side oracle then uses the sum of these link budgets as the
        global super-arm budget, so useful CAVs can consume more budget and
        redundant CAVs can be suppressed by no-send.
        """
        state_name = self._state_name_for_sender(data_dict, batch_idx, sender_idx)
        profile = self._profile_for_state(state_name)

        if state_name == "ego_or_padding":
            return state_name, profile, 0.0

        if self._use_channel_profile_budget():
            link_budget_bytes = self._channel_profile_budget_bytes(profile)
        else:
            link_budget_bytes = self._per_link_budget_bytes(num_collaborators)

        return state_name, profile, float(link_budget_bytes)

    # ------------------------------------------------------------------
    # Byte-stream + FEC cost estimation
    # ------------------------------------------------------------------

    def _estimate_byte_stream_fec_cost(
        self,
        feature_shape: Sequence[int],
        action: PDFARCEAction,
        budget_bytes: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Estimate communication cost for C2MAB proposal ranking.

        Final setting: quantization mode is treated as a rate-distortion
        operating point under one global shared bandwidth budget.

            fp32 -> high fidelity / high budget
            fp16 -> medium-high fidelity / medium budget
            int8 -> compressed / low budget
            int4 -> strongly compressed / very low budget

        The global oracle still enforces:
            sum(selected.cost_bytes) <= global_budget_bytes

        Therefore this does not violate the 1/5/27 Mbps shared bandwidth
        constraint. It only changes how each quantized action requests a share
        of that global budget.
        """
        if getattr(action, "is_no_send", False):
            return {
                "feasible": True,
                "send": 0,
                "quant_mode": str(action.quant_mode),
                "fec_type": "none",
                "rho": 0.0,
                "raw_fp32_bytes": 0.0,
                "source_bytes": 0.0,
                "source_packets": 0,
                "parity_packets": 0,
                "encoded_packets": 0,
                "metadata_bytes": 0.0,
                "encoded_bytes": 0.0,
                "estimated_transmitted_bytes": 0.0,
                "max_tx_packets_under_budget": 0,
                "effective_packet_ratio": 0.0,
                "packet_size_bytes": int(self.packet_size_bytes),
                "budget_bytes": float(budget_bytes) if budget_bytes is not None else None,
                "proposal_budget_share": 0.0,
                "cost_model": "allocation_aware_quant_share",
            }

        raw_fp32 = raw_feature_bytes_fp32(feature_shape)
        q = str(action.quant_mode).strip().lower()
        quant_ratio = float(QUANT_RATIO_TO_FP32.get(q, 0.5))

        source_bytes = float(raw_fp32 * quant_ratio)

        Lp = int(self.packet_size_bytes)
        packet_unit = float(Lp + max(0, self.metadata_bytes_per_packet))
        source_packets = int(math.ceil(source_bytes / max(Lp, 1))) if source_bytes > 0 else 0

        rho = float(getattr(action, "redundancy_ratio", 0.0))
        parity_packets = int(math.ceil(source_packets * max(rho, 0.0)))
        encoded_packets = int(source_packets + parity_packets)

        metadata_bytes = float(encoded_packets * max(0, self.metadata_bytes_per_packet))
        encoded_bytes = float(encoded_packets * Lp + metadata_bytes)

        if budget_bytes is None:
            target_tx_bytes = float(encoded_bytes)
            proposal_share = 1.0
        else:
            budget = float(max(0.0, budget_bytes))

            # Quantization-aware rate allocation:
            #   fp32: 1.00
            #   fp16: 0.50
            #   int8: 0.25
            #   int4: 0.125
            #
            # Redundancy increases requested budget; the final value is clipped
            # by the global budget.
            proposal_share = float(quant_ratio) * float(1.0 + max(rho, 0.0))
            proposal_share = max(0.02, min(1.0, proposal_share))

            target_tx_bytes = float(min(encoded_bytes, budget * proposal_share))

            # At least one packet if the action is feasible.
            if target_tx_bytes > 0.0 and target_tx_bytes < packet_unit:
                target_tx_bytes = packet_unit

        if encoded_packets <= 0 or target_tx_bytes <= 0.0:
            max_tx_packets = 0
        else:
            max_tx_packets = int(
                min(
                    encoded_packets,
                    math.floor(target_tx_bytes / packet_unit),
                )
            )

        feasible = max_tx_packets > 0
        estimated_tx = float(max_tx_packets * packet_unit)
        effective_ratio = float(max_tx_packets / max(1, encoded_packets))

        return {
            "feasible": bool(feasible),
            "send": int(action.send),
            "quant_mode": q,
            "fec_type": str(getattr(action, "fec_type", "none")),
            "rho": float(rho),
            "raw_fp32_bytes": float(raw_fp32),
            "source_bytes": float(source_bytes),
            "source_packets": int(source_packets),
            "parity_packets": int(parity_packets),
            "encoded_packets": int(encoded_packets),
            "metadata_bytes": float(metadata_bytes),
            "encoded_bytes": float(encoded_bytes),
            "estimated_transmitted_bytes": float(estimated_tx),
            "max_tx_packets_under_budget": int(max_tx_packets),
            "effective_packet_ratio": float(effective_ratio),
            "packet_size_bytes": int(Lp),
            "budget_bytes": float(budget_bytes) if budget_bytes is not None else None,
            "proposal_budget_share": float(proposal_share),
            "cost_model": "allocation_aware_quant_share",
        }


    # ------------------------------------------------------------------
    # Cache / records
    # ------------------------------------------------------------------

    def _cache_quality(self, ego_id: Any, sender_id: Any) -> float:
        return float(self.last_cache_quality.get(self._policy_key(ego_id, sender_id), 0.0))

    def _update_cache_quality_from_record(
        self,
        ego_id: Any,
        sender_id: Any,
        record: Dict[str, Any],
    ) -> None:
        q = None

        for path in (
            ["quality", "q_recv"],
            ["recovery", "recovery_ratio"],
            ["partial_reconstruction", "recovery_ratio"],
            ["mean_recovery_ratio"],
        ):
            val = _safe_get_nested(record, path)
            if val is not None:
                try:
                    q = float(val)
                    break
                except Exception:
                    pass

        if q is None:
            q = 0.0

        self.last_cache_quality[self._policy_key(ego_id, sender_id)] = max(
            0.0,
            min(1.0, q),
        )

    def _make_no_send_record(
        self,
        feature: torch.Tensor,
        frame_id: Any,
        ego_id: Any,
        sender_id: Any,
        action: Optional[PDFARCEAction] = None,
        reason: str = "not_selected_by_oracle",
    ) -> Dict[str, Any]:
        return {
            "frame_id": frame_id,
            "link_id": repr((ego_id, sender_id)),
            "agent_index": int(sender_id) if isinstance(sender_id, int) else str(sender_id),
            "ego_index": int(ego_id) if isinstance(ego_id, int) else str(ego_id),
            "arce_mode": "dc2mab",
            "applied": False,
            "bypassed": False,
            "no_send": True,
            "reason": reason,
            "action": action.as_dict() if action is not None else {"send": 0},
            "transmitted_bytes": 0.0,
            "received_bytes": 0.0,
            "actual_transmitted_bytes": 0.0,
            "actual_received_bytes": 0.0,
            "input_shape": tuple(int(x) for x in feature.shape),
            "output_shape": tuple(int(x) for x in feature.shape),
            "quality": {
                "q_recv": 0.0,
            },
        }

    # ------------------------------------------------------------------
    # Main APIs
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # mask complementarity utilities
    # ------------------------------------------------------------------
    # Thin wrappers kept for backward compatibility with existing call sites.
    # Actual implementation lives in c2mab_complementarity.py.

    def _mask_to_bool_2d(self, mask):
        return mask_to_bool_2d(mask)

    def _mask_complementarity(self, sender_mask, ego_mask) -> float:
        return mask_complementarity(sender_mask, ego_mask)

    def _mask_to_float_2d(self, mask):
        return mask_to_float_2d(mask)

    def _confidence_advantage_complementarity(
        self,
        sender_score,
        ego_score,
        threshold: float = 0.05,
    ):
        return confidence_advantage_complementarity(
            sender_score,
            ego_score,
            threshold=threshold,
        )

    def communicate_agent_features(
        self,
        features: torch.Tensor,
        frame_id: Optional[int] = None,
        ego_index: int = 0,
        data_dict: Optional[Dict[str, Any]] = None,
        batch_idx: int = 0,
        update_cache: bool = True,
        return_records: bool = True,
        message_masks: Optional[torch.Tensor] = None,
    
        local_cav_confidences: Optional[torch.Tensor] = None,
    ):
        """
        Communicate one batch item's features [N, C, H, W].

        Final GRACE semantics:
            1. Each non-ego CAV builds a context vector.
            2. Each CAV proposes one C2MAB action.
            3. Ego-side oracle performs diversity-aware greedy knapsack.
            4. Selected CAVs communicate with selected actions.
            5. Unselected CAVs are strict no-send.
        """
        if features.dim() != 4:
            raise ValueError(f"Expected features [N,C,H,W], got {tuple(features.shape)}")

        n = int(features.shape[0])
        ego_id = int(ego_index)

        collaborator_indices = [
            sender_idx for sender_idx in range(n)
            if int(sender_idx) != int(ego_index)
        ]
        num_collaborators = len(collaborator_indices)

        # Initial fallback budgets. They may be overwritten by channel-profile budgets.
        total_budget_bytes = self._system_budget_bytes()
        per_link_budget_bytes = self._per_link_budget_bytes(num_collaborators)

        budget_source_cfg, budget_scope_cfg = self._budget_source_scope()
        use_channel_profile_budget = self._use_channel_profile_budget()

        ego_conf = float(self.last_ego_confidence)

        link_states: Dict[int, str] = {}
        link_profiles: Dict[int, Dict[str, Any]] = {}
        link_budgets: Dict[int, float] = {}

        for sender_idx in collaborator_indices:
            state_name, profile, link_budget_bytes = self._prepare_link_channel_budget(
                data_dict=data_dict,
                batch_idx=batch_idx,
                sender_idx=sender_idx,
                num_collaborators=num_collaborators,
            )
            if state_name == "ego_or_padding":
                continue

            link_states[sender_idx] = state_name
            link_profiles[sender_idx] = profile
            link_budgets[sender_idx] = float(link_budget_bytes)

        # Final global shared bandwidth budget:
        # In the final experimental setting, the Markov channel state defines
        # ONE ego-side shared bandwidth budget for all collaborators:
        #
        #   bad    = 1  Mbps  -> 12500  bytes at tx_window_ms=100
        #   medium = 5  Mbps  -> 62500  bytes at tx_window_ms=100
        #   good   = 27 Mbps  -> 337500 bytes at tx_window_ms=100
        #
        # This is NOT a per-link bandwidth. All collaborators compete for this
        # single total_budget_bytes in the ego oracle.
        #
        # Note:
        # _prepare_link_channel_budget() is still called above to obtain the
        # current Markov channel profile/state. Under the intended setting,
        # all collaborators in the same frame should share the same global
        # channel state. If multiple states appear, we use the first valid
        # profile as the global profile and expose nominal equal shares only
        # for logging/debugging.
        if use_channel_profile_budget and link_profiles:
            first_sender = next(iter(link_profiles.keys()))
            global_profile = link_profiles[first_sender]

            total_budget_bytes = float(
                self._channel_profile_budget_bytes(global_profile)
            )
            per_link_budget_bytes = (
                float(total_budget_bytes) / float(max(1, len(link_budgets)))
            )

            # Logging-only nominal equal share. The oracle still allocates
            # total_budget_bytes adaptively according to candidate action costs.
            link_budgets = {
                int(k): float(per_link_budget_bytes)
                for k in link_budgets.keys()
            }

        proposals: List[CAVProposal] = []
        no_send_candidates: Dict[int, PDFARCEAction] = {}

        for sender_idx in collaborator_indices:
            state_name = link_states.get(sender_idx, "medium")
            if state_name == "ego_or_padding":
                continue

            profile = link_profiles.get(sender_idx, self._profile_for_state(state_name))
            link_budget_bytes = float(link_budgets.get(sender_idx, per_link_budget_bytes))

            # For global_sum_link, proposal budget is the global pool.
            # The selected proposal consumes selected.cost_bytes from this pool.
            # For legacy equal-split, proposal budget remains per-link.
            if use_channel_profile_budget and budget_scope_cfg == "global_sum_link":
                proposal_budget_bytes = float(total_budget_bytes)
            else:
                proposal_budget_bytes = float(link_budget_bytes)

            latency_ms = _profile_scalar(
                profile.get("delay_ms", profile.get("fixed_delay_ms", 50.0)),
                50.0,
            )
            cache_q = self._cache_quality(ego_id, sender_idx)

            comp_i_ego = 0.0
            comp_source = "none"
            sender_mask = None
            ego_mask = None
            sender_mask_for_oracle = None
            comp_stats = {
                "mode": "none",
                "sender_valid": False,
                "ego_valid": False,
            }

            if message_masks is not None:
                try:
                    mask_threshold = float(
                        self.arce_cfg.get("patch_selection", {}).get("mask_threshold", 0.05)
                    )

                    # Here message_masks is expected to be Where2comm confidence maps.
                    # sender_mask / ego_mask are continuous confidence scores.
                    ego_mask = message_masks[int(ego_index)]
                    sender_mask = message_masks[int(sender_idx)]

                    comp_i_ego, sender_mask_for_oracle, comp_stats = (
                        self._confidence_advantage_complementarity(
                            sender_mask,
                            ego_mask,
                            threshold=mask_threshold,
                        )
                    )
                    comp_source = "where2comm_confidence_advantage"

                    # If confidence-map advantage is exactly zero, keep it zero.
                    # Do not replace it with sender coverage ratio; that would make
                    # the policy prefer large masks rather than true new information.
                    if sender_mask_for_oracle is None:
                        sender_mask_for_oracle = self._mask_to_bool_2d(sender_mask)

                except Exception as exc:
                    comp_i_ego = 0.0
                    comp_source = f"fallback_zero:{type(exc).__name__}"
                    sender_mask = None
                    ego_mask = None
                    sender_mask_for_oracle = None
                    comp_stats = {
                        "mode": "exception",
                        "error": f"{type(exc).__name__}: {exc}",
                    }

            # Bounded complementarity normalization.
            # Raw mask complementarity is often around 1e-5~1e-4, much smaller
            # than other context dimensions in [0,1]. We map it to [0,1] using
            # a saturating transform rather than a hard-coded linear multiplier.
            comp_raw = float(comp_i_ego)
            # Step 8: complementarity_raw is already designed as a normalized
            # confidence-advantage ratio in [0, 1].  The old exponential mapping
            #   1 - exp(-comp_raw / tau)
            # with a fixed tau=5e-5 easily saturates or collapses the feature.
            # Therefore, use clipped raw complementarity by default.
            #
            # Optional legacy mode:
            #   arce.complementarity_norm: exp_tau
            #   arce.complementarity_tau: <float>
            comp_norm_mode = str(self.arce_cfg.get("complementarity_norm", "raw_clip")).lower()
            if comp_norm_mode in ("exp", "exp_tau", "legacy_exp"):
                comp_tau = float(self.arce_cfg.get("complementarity_tau", 5e-5))
                comp_tau = max(comp_tau, 1e-12)
                comp_norm = 1.0 - math.exp(-max(0.0, comp_raw) / comp_tau)
            else:
                comp_norm = max(0.0, min(1.0, float(comp_raw)))
            comp_norm = max(0.0, min(1.0, float(comp_norm)))

            context = self.context_builder.build(
                channel_profile=profile,
                latency_ms=latency_ms,
                ego_confidence=ego_conf,
                cache_quality=cache_q,
                complementarity=comp_norm,
                cav_confidence=get_cav_confidence(local_cav_confidences, sender_idx, default=0.0),
            )

            feasible = []
            for action in self.actions:
                if getattr(action, "is_no_send", False):
                    continue

                cost_info = self._estimate_byte_stream_fec_cost(
                    feature_shape=features.shape[1:],
                    action=action,
                    budget_bytes=proposal_budget_bytes,
                )

                if not bool(cost_info["feasible"]):
                    continue

                feasible.append(
                    (
                        action,
                        float(cost_info["estimated_transmitted_bytes"]),
                        cost_info,
                    )
                )

            if not feasible:
                no_send_candidates[sender_idx] = self.no_send_action
                continue

            policy = self.get_policy(ego_id, sender_idx)

            scored = []
            for a, c, info in feasible:
                score = policy.score(a.action_id, context.vector)
                scored.append((score, a, float(c), info))

            scored_by_ucb = sorted(
                scored,
                key=lambda x: float(x[0].ucb),
                reverse=True,
            )

            candidate_map = {}

            def _add_candidate(item, reason: str):
                score, action, cost, cost_info = item
                old_item = candidate_map.get(action.action_id)
                if old_item is None:
                    candidate_map[action.action_id] = [score, action, cost, cost_info, {reason}]
                else:
                    old_item[4].add(reason)

            # 1) LinUCB top-k actions.
            for item in scored_by_ucb[: self.sender_topk_actions]:
                _add_candidate(item, "topk_ucb")

            # 2) Ensure fp32/fp16/int8/int4 all have a chance when feasible.
            if self.sender_force_quant_coverage:
                quant_groups = {}
                for item in scored:
                    _, action, _, _ = item
                    q = str(getattr(action, "quant_mode", "unknown")).lower()
                    quant_groups.setdefault(q, []).append(item)
                for q, items in quant_groups.items():
                    best_q = max(items, key=lambda x: float(x[0].ucb))
                    _add_candidate(best_q, f"best_ucb_quant_{q}")

            # 3) Add low-cost candidates, especially INT8/INT4, so the ego
            # oracle can select multiple CAVs under a tight shared budget.
            if self.sender_include_low_cost:
                cheapest_all = min(scored, key=lambda x: float(x[2]))
                _add_candidate(cheapest_all, "cheapest_all")

                quant_groups = {}
                for item in scored:
                    _, action, _, _ = item
                    q = str(getattr(action, "quant_mode", "unknown")).lower()
                    quant_groups.setdefault(q, []).append(item)
                for q, items in quant_groups.items():
                    cheapest_q = min(items, key=lambda x: float(x[2]))
                    _add_candidate(cheapest_q, f"cheapest_quant_{q}")

            sender_candidates = list(candidate_map.values())
            sender_candidates = sorted(
                sender_candidates,
                key=lambda x: (float(x[0].ucb) / max(float(x[2]), 1.0)),
                reverse=True,
            )

            for local_rank, (score, cand_action, cand_cost, cand_cost_info, reasons) in enumerate(sender_candidates):
                proposals.append(
                    CAVProposal(
                        ego_id=ego_id,
                        sender_id=sender_idx,
                        action=cand_action,
                        action_id=cand_action.action_id,
                        context=context,
                        ucb=score.ucb,
                        mean=score.mean,
                        bonus=score.bonus,
                        cost_bytes=float(cand_cost),
                        record={
                            "channel_state": state_name,
                            "complementarity": float(comp_i_ego),
                            "complementarity_source": str(comp_source),
                            "complementarity_stats": copy.deepcopy(comp_stats),
                            "channel_profile": profile,
                            "link_budget_bytes": float(link_budget_bytes),
                            "proposal_budget_bytes": float(proposal_budget_bytes),
                            "per_link_budget_bytes": float(per_link_budget_bytes),
                            "system_budget_bytes": float(total_budget_bytes),
                            "num_collaborators": int(num_collaborators),
                            "budget_scope": str(budget_scope_cfg),
                            "budget_source": str(budget_source_cfg),
                            "proposal_cost_model": "byte_stream_quantize_first_with_fec",
                            "estimated_tx_bytes": float(cand_cost),
                            "estimated_source_bytes": float(cand_cost_info["source_bytes"]),
                            "estimated_parity_bytes": float(
                                cand_cost_info["parity_packets"] * self.packet_size_bytes
                            ),
                            "estimated_metadata_bytes": float(cand_cost_info["metadata_bytes"]),
                            "estimated_encoded_bytes": float(cand_cost_info["encoded_bytes"]),
                            "estimated_packet_ratio": float(cand_cost_info["effective_packet_ratio"]),
                            "num_source_packets": int(cand_cost_info["source_packets"]),
                            "num_parity_packets": int(cand_cost_info["parity_packets"]),
                            "num_encoded_packets": int(cand_cost_info["encoded_packets"]),
                            "max_tx_packets_under_budget": int(
                                cand_cost_info["max_tx_packets_under_budget"]
                            ),
                            "fec_type": str(cand_cost_info["fec_type"]),
                            "rho": float(cand_cost_info["rho"]),
                            "packet_size_bytes": int(self.packet_size_bytes),
                            "bandwidth_selection": copy.deepcopy(cand_cost_info),
                            "num_feasible_actions": int(len(feasible)),
                            "num_sender_candidate_actions": int(len(sender_candidates)),
                            "complementarity_raw": float(comp_i_ego),
                            "complementarity_normalized": float(comp_norm),
                            "sender_candidate_rank": int(local_rank),
                            "sender_candidate_reasons": sorted(str(x) for x in reasons),
                            "sender_topk_actions": int(self.sender_topk_actions),
                            "sender_force_quant_coverage": bool(self.sender_force_quant_coverage),
                            "sender_include_low_cost": bool(self.sender_include_low_cost),
                        },
                        mask=sender_mask_for_oracle,
                        ego_mask=self._mask_to_bool_2d(ego_mask),
                        complementarity=float(comp_i_ego),
                    )
                )

        oracle_result = self.oracle.select(proposals, budget_bytes=total_budget_bytes)
        selected_by_sender = {
            int(p.sender_id): p for p in oracle_result["selected"]
        }

        out = features.clone()
        frame_records = []
        used_cost = 0.0

        for sender_idx in collaborator_indices:
            selected = selected_by_sender.get(sender_idx, None)

            if selected is None:
                action = no_send_candidates.get(sender_idx, self.no_send_action)

                # Strict no-send:
                # no communication and no current-frame collaborative information.
                out[sender_idx] = torch.zeros_like(out[sender_idx])

                rec = self._make_no_send_record(
                    out[sender_idx],
                    frame_id,
                    ego_id,
                    sender_idx,
                    action,
                )
                rec["system_budget"] = {
                    "budget_scope": str(budget_scope_cfg),
                    "budget_source": str(budget_source_cfg),
                    "system_budget_mbps": float(self.system_budget_mbps),
                    "tx_window_ms": float(self.tx_window_ms),
                    "system_budget_bytes": float(total_budget_bytes),
                    "num_collaborators": int(num_collaborators),
                    "per_link_budget_bytes": float(per_link_budget_bytes),
                    "link_budgets": {str(k): float(v) for k, v in link_budgets.items()},
                }
                # Step 5: no-send fallback should also be a learnable arm.
                # It has zero cost and zero received quality, but still receives
                # a proxy reward update so LinUCB can learn when not sending is useful.
                try:
                    if action is not None:
                        policy = self.get_policy(ego_id, sender_idx)
                        context = self.context_builder.build(
                            channel_profile=link_profiles.get(sender_idx, self._profile_for_state(link_states.get(sender_idx, "medium"))),
                            latency_ms=float(link_profiles.get(sender_idx, {}).get("delay_ms", 0.0)),
                            ego_confidence=float(ego_conf),
                            cache_quality=float(cache_q),
                            complementarity=0.0,
                            cav_confidence=get_cav_confidence(local_cav_confidences, sender_idx, default=0.0),
                        )
                        rec["pdf_action"] = action.as_dict()
                        rec["context_vector"] = context.vector.tolist()
                        rec["selected_for_update"] = True
                        rec["no_send_update"] = True
                        self.pending_reward.add(
                            {
                                "ego_id": ego_id,
                                "sender_id": sender_idx,
                                "action_id": action.action_id,
                                "context_vector": context.vector,
                                "cost_bytes": 0.0,
                                "link_budget_bytes": float(per_link_budget_bytes),
                                "delay_ms": 0.0,
                                "q_recv": 0.0,
                                "q_eff": 0.0,
                                "budget_violation": False,
                                "quant_mode": str(getattr(action, "quant_mode", "")).lower(),
                                "channel_state": str(link_states.get(sender_idx, "medium")).lower(),
                                "redundancy_ratio": float(getattr(action, "redundancy_ratio", 0.0)),
                                "cache_enabled": int(getattr(action, "cache_enabled", 0)),
                                "cache_quality": float(cache_q),
                                "fec_gain": 0.0,
                                "complementarity_raw": 0.0,
                                "complementarity_normalized": 0.0,
                                "contribution_weight": 0.0,
                                "no_send_update": True,
                            }
                        )
                except Exception as exc:
                    rec["no_send_update_error"] = f"{type(exc).__name__}: {exc}"

                frame_records.append(rec)
                self._append_record(rec)
                continue

            pdf_action: PDFARCEAction = selected.action

            arce_action = normalize_runtime_action(
                pdf_action.to_arce_action(),
                send=int(pdf_action.send),
                cache_enabled=int(pdf_action.cache_enabled),
                action_id=str(pdf_action.action_id),
            )

            state_name = selected.record.get("channel_state", "medium")
            allocated_budget_bytes = float(
                selected.record.get(
                    "estimated_tx_bytes",
                    selected.record.get(
                        "proposal_budget_bytes",
                        selected.record.get("link_budget_bytes", total_budget_bytes),
                    ),
                )
            )

            try:
                recovered, record = self.executor.communicate_feature(
                    feature=features[sender_idx],
                    link_id=(batch_idx, ego_id, sender_idx),
                    frame_id=frame_id,
                    agent_index=sender_idx,
                    ego_index=ego_index,
                    channel_state=state_name,
                    action_override=arce_action,
                    budget_bytes=float(allocated_budget_bytes),
                    message_mask=(
                        message_masks[sender_idx]
                        if message_masks is not None
                        else None
                    ),
                    complementarity=float(getattr(selected, "complementarity", 0.0)),
                    update_cache=update_cache,
                    return_result=False,
                )
            except TypeError as exc:
                raise TypeError(
                    "ARCEFixedComm.communicate_feature does not accept "
                    "action_override / budget_bytes / channel_state yet. "
                    "Update arce_fixed_comm.py first."
                ) from exc

            out[sender_idx] = recovered

            record = copy.deepcopy(record)
            record["dc2mab"] = {
                "selected": True,
                "proposal": selected.as_dict(),
                "oracle": {
                    "budget_bytes": float(total_budget_bytes),
                    "used_budget_bytes": float(oracle_result["used_budget_bytes"]),
                    "remaining_budget_bytes": float(oracle_result["remaining_budget_bytes"]),
                    "budget_scope": str(budget_scope_cfg),
                    "budget_source": str(budget_source_cfg),
                    "oracle_raw": {
                        k: v for k, v in oracle_result.items()
                        if k not in ("selected",)
                    },
                },
            }
            record["pdf_action"] = pdf_action.as_dict()
            record["system_budget"] = {
                "budget_scope": str(budget_scope_cfg),
                "budget_source": str(budget_source_cfg),
                "system_budget_mbps": float(self.system_budget_mbps),
                "tx_window_ms": float(self.tx_window_ms),
                "system_budget_bytes": float(total_budget_bytes),
                "num_collaborators": int(num_collaborators),
                "per_link_budget_bytes": float(per_link_budget_bytes),
                "link_budget_bytes": float(
                    selected.record.get("link_budget_bytes", per_link_budget_bytes)
                ),
                "proposal_budget_bytes": float(
                    selected.record.get("proposal_budget_bytes", total_budget_bytes)
                ),
                "allocated_budget_bytes": float(allocated_budget_bytes),
                "link_budgets": {str(k): float(v) for k, v in link_budgets.items()},
            }

            tx_bytes = float(
                record.get(
                    "actual_transmitted_bytes",
                    record.get(
                        "transmitted_bytes",
                        record.get("tx_bytes", selected.cost_bytes),
                    ),
                )
            )

            est = float(
                selected.record.get(
                    "estimated_tx_bytes",
                    selected.record.get("estimated_transmitted_bytes", 0.0),
                )
                or 0.0
            )
            allocated = float(allocated_budget_bytes or 0.0)
            actual = float(tx_bytes)

            record["budget_consistency"] = {
                "estimated_tx_bytes": est,
                "allocated_budget_bytes": allocated,
                "actual_tx_bytes": actual,
                "actual_over_est": float(actual / max(est, 1.0)),
                "actual_over_allocated": float(actual / max(allocated, 1.0)),
            }

            used_cost += tx_bytes

            self._update_cache_quality_from_record(ego_id, sender_idx, record)

            frame_records.append(record)
            self._append_record(record)

            # ------------------------------------------------------------------
            # Reward preparation
            # ------------------------------------------------------------------
            latency_info = {}
            if isinstance(record.get("latency", None), dict):
                latency_info = record.get("latency", {})
            elif isinstance(record.get("channel", None), dict):
                latency_info = record.get("channel", {}).get("latency", {}) or {}

            recovery_info = record.get("recovery", {}) if isinstance(record.get("recovery", {}), dict) else {}
            quality_info = record.get("quality", {}) if isinstance(record.get("quality", {}), dict) else {}
            patch_summary = record.get("patch_summary", {}) if isinstance(record.get("patch_summary", {}), dict) else {}

            selected_src = float(
                patch_summary.get(
                    "num_selected_source_patches",
                    patch_summary.get("num_source_packets", 0.0),
                )
                or 0.0
            )
            missing_by_loss = float(
                patch_summary.get(
                    "num_missing_by_loss",
                    patch_summary.get("num_lost_by_bernoulli", 0.0),
                )
                or 0.0
            )
            fec_recovered = float(
                patch_summary.get(
                    "num_fec_recovered_patches",
                    patch_summary.get("num_fec_recovered_packets", 0.0),
                )
                or 0.0
            )

            if selected_src > 0.0:
                q_recv = max(
                    0.0,
                    min(
                        1.0,
                        1.0 - max(0.0, missing_by_loss - fec_recovered) / selected_src,
                    ),
                )
            else:
                q_recv = float(
                    quality_info.get(
                        "q_recv",
                        recovery_info.get("q_recv", record.get("q_recv", 0.0)),
                    )
                )

            delay_ms = _profile_scalar(
                latency_info.get(
                    "total_delay_ms",
                    latency_info.get(
                        "delay_ms",
                        link_profiles.get(sender_idx, {}).get("delay_ms", 0.0),
                    ),
                ),
                0.0,
            )

            q_eff = effective_receive_quality(
                q_recv,
                delay_ms,
                tau_stale_ms=self.reward_tau_stale_ms,
            )

            reward_budget = float(
                selected.record.get(
                    "proposal_budget_bytes",
                    selected.record.get("link_budget_bytes", total_budget_bytes),
                )
            )
            link_violation = bool(tx_bytes > reward_budget + 1e-6)

            # Step 7: use conservative FEC reward.
            # Reward the fraction of total selected source packets recovered by FEC,
            # not merely the fraction of lost packets recovered.
            # This avoids over-rewarding FEC when only a few packets were lost.
            try:
                if float(selected_src) > 0.0:
                    _fec_gain_for_reward = float(fec_recovered) / max(float(selected_src), 1.0)
                else:
                    _fec_gain_for_reward = 0.0
            except Exception:
                _fec_gain_for_reward = 0.0
            _fec_gain_for_reward = max(0.0, min(1.0, _fec_gain_for_reward))

            try:
                _cache_quality_for_reward = float(cache_q)
            except Exception:
                try:
                    _cache_quality_for_reward = float(selected.record.get("cache_quality", 0.0))
                except Exception:
                    _cache_quality_for_reward = 0.0
            _cache_quality_for_reward = max(0.0, min(1.0, _cache_quality_for_reward))

            try:
                _cache_enabled_for_reward = int(getattr(selected.action, "cache_enabled", 0))
            except Exception:
                _cache_enabled_for_reward = 0

            try:
                _redundancy_ratio_for_reward = float(getattr(selected.action, "redundancy_ratio", 0.0))
            except Exception:
                _redundancy_ratio_for_reward = 0.0

            self.pending_reward.add(
                {
                    "ego_id": ego_id,
                    "sender_id": sender_idx,
                    "action_id": selected.action_id,
                    "context_vector": selected.context.vector,
                    "cost_bytes": float(tx_bytes),
                    "link_budget_bytes": float(reward_budget),
                    "delay_ms": float(delay_ms),
                    "q_recv": float(q_recv),
                    "q_eff": float(q_eff),
                    "budget_violation": bool(link_violation),
                    "quant_mode": str(getattr(selected.action, "quant_mode", "")).lower(),
                    "channel_state": str(selected.record.get("channel_state", "medium")).lower(),
                    "redundancy_ratio": float(_redundancy_ratio_for_reward),
                    "cache_enabled": int(_cache_enabled_for_reward),
                    "cache_quality": float(_cache_quality_for_reward),
                    "fec_gain": float(_fec_gain_for_reward),
                    "complementarity_raw": float(selected.record.get("complementarity_raw", selected.record.get("complementarity", 0.0))),
                    "complementarity_normalized": float(selected.record.get("complementarity_normalized", selected.record.get("complementarity", 0.0))),
                    "contribution_weight": float(
                        selected.record.get("estimated_packet_ratio", 1.0)
                    ),
                }
            )

        superarm_record = {
            "frame_id": frame_id,
            "batch_idx": int(batch_idx),
            "ego_id": str(ego_id),
            "dc2mab_superarm": {
                "budget_bytes": float(total_budget_bytes),
                "budget_scope": str(budget_scope_cfg),
                "budget_source": str(budget_source_cfg),
                "system_budget_mbps": float(self.system_budget_mbps),
                "tx_window_ms": float(self.tx_window_ms),
                "num_collaborators": int(num_collaborators),
                "per_link_budget_bytes": float(per_link_budget_bytes),
                "link_budgets": {str(k): float(v) for k, v in link_budgets.items()},
                "link_states": {str(k): str(v) for k, v in link_states.items()},
                "used_budget_bytes": float(used_cost),
                "selected_sender_ids": [str(x) for x in selected_by_sender.keys()],
                "selected_action_ids": [
                    p.action_id for p in selected_by_sender.values()
                ],
                "num_selected": len(selected_by_sender),
                "oracle": {
                    k: v for k, v in oracle_result.items()
                    if k not in ("selected",)
                },
                "packetization": {
                    "mode": "byte_stream",
                    "packet_size_bytes": int(self.packet_size_bytes),
                    "quantize_first": True,
                },
                "loss_model": {
                    "type": "bernoulli",
                    "good": 0.05,
                    "medium": 0.20,
                    "bad": 0.35,
                },
                "delay_model": {
                    "type": "fixed_state_delay",
                    "good": 10.0,
                    "medium": 50.0,
                    "bad": 100.0,
                    "bad_temporal_source": "previous_frame",
                },
                "fec_redundancy": {
                    "enabled": True,
                    "rho_values": [0.0, 0.25, 0.5],
                    "cost_model": "source_packets + ceil(source_packets * rho)",
                },
            },
        }
        self._append_record(superarm_record)

        if return_records:
            return out, frame_records
        return out

    def communicate_flattened_features(
        self,
        features: torch.Tensor,
        record_len: Any,
        data_dict: Optional[Dict[str, Any]] = None,
        frame_id: Optional[int] = None,
        ego_index: Optional[int] = 0,
        update_cache: bool = True,
        return_records: bool = True,
        message_masks: Optional[torch.Tensor] = None,
    
        local_cav_confidences: Optional[torch.Tensor] = None,
    ):
        """
        Communicate OpenCOOD flattened features [sum(record_len), C, H, W].
        """
        if features.dim() != 4:
            raise ValueError(
                f"Expected flattened features [sumN,C,H,W], got {tuple(features.shape)}"
            )

        record_lens = _as_list_record_len(record_len)

        outputs = []
        all_records = []
        offset = 0

        for b, n in enumerate(record_lens):
            group = features[offset: offset + n]

            group_masks = None
            if message_masks is not None:
                group_masks = message_masks[offset: offset + n]

            out_group, records = self.communicate_agent_features(
                group,
                frame_id=frame_id,
                ego_index=int(ego_index or 0),
                data_dict=data_dict,
                batch_idx=b,
                update_cache=update_cache,
                return_records=True,
                message_masks=group_masks,
            
                local_cav_confidences=local_cav_confidences,
            )

            outputs.append(out_group)
            all_records.extend(records)

            offset += n

        out = torch.cat(outputs, dim=0) if outputs else features

        if return_records:
            return out, all_records
        return out

    def update_with_proxy_reward(
        self,
        collab_confidence: float,
        ego_confidence: Optional[float] = None,
        budget_bytes: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Update selected actions after detection confidence is available.

        This final version uses link-level proxy rewards and does not require
        ground-truth AP. AP is only used by the offline evaluator.
        """
        if ego_confidence is None:
            ego_confidence = self.last_ego_confidence

        pending = self.pending_reward.pop_all()
        delta_conf = float(collab_confidence) - float(ego_confidence)

        raw_ws = [max(float(x.get("contribution_weight", 0.0)), 0.0) for x in pending]
        sw = sum(raw_ws)

        if pending and sw <= 1e-12:
            raw_ws = [1.0 for _ in pending]
            sw = float(len(pending))

        reward_infos = []

        for item, raw_w in zip(pending, raw_ws):
            w = float(raw_w) / max(sw, 1e-12)

            reward, info = c2mab_ap_gain_reward(
                ap_proxy_gain=delta_conf,
                contribution_weight=w,
                cost_bytes=float(item.get("cost_bytes", 0.0)),
                budget_bytes=float(
                    item.get("link_budget_bytes", budget_bytes or 1.0)
                ),
                delay_ms=float(item.get("delay_ms", 0.0)),
                budget_violation=bool(item.get("budget_violation", False)),
                quant_mode=str(item.get("quant_mode", "fp32")),
                lambda_cost=float(getattr(self, "reward_lambda_cost", 0.10)),
                lambda_delay=float(getattr(self, "reward_lambda_delay", 0.05)),
                lambda_quant=float(getattr(self, "reward_lambda_quant", 0.05)),
                lambda_violate=float(getattr(self, "reward_lambda_violate", 1.0)),
                stale_max_ms=self.reward_stale_max_ms,
            )

            policy = self.get_policy(item["ego_id"], item["sender_id"])
            _policy_t_before = int(getattr(policy, "t", -1))
            _context_vector = item["context_vector"]
            # Step 9: pass channel profile into CW-D-LinUCB so feedback
            # weighting can use physical link quality instead of silently
            # falling back to w=1.
            _channel_profile = item.get("channel_profile", None)
            if not isinstance(_channel_profile, dict):
                _q_recv_for_weight = float(item.get("q_recv", item.get("q_eff", 1.0)))
                _q_recv_for_weight = max(0.0, min(1.0, _q_recv_for_weight))
                _channel_profile = {
                    "loss_rate": float(1.0 - _q_recv_for_weight),
                }

            _feedback_weight = policy.update(
                item["action_id"],
                _context_vector,
                reward,
                channel_profile=_channel_profile,
            )
            _policy_t_after = int(getattr(policy, "t", -1))

            _corruption_info = {}
            if hasattr(policy, "last_feedback_corruption_info"):
                _corruption_info = dict(
                    policy.last_feedback_corruption_info.get(
                        item["action_id"], {}
                    )
                )

            info["policy_update_debug"] = {
                "action_id": str(item["action_id"]),
                "reward": float(reward),
                "context_dim": int(len(_context_vector)),
                "policy_t_before": int(_policy_t_before),
                "policy_t_after": int(_policy_t_after),
                "policy_t_delta": int(_policy_t_after - _policy_t_before),
                "feedback_weight": float(_feedback_weight),
                "feedback_corruption_C": float(
                    _corruption_info.get("feedback_corruption_C", 0.0)
                ),
                "feedback_corruption_info": dict(_corruption_info),
                "channel_profile": dict(_channel_profile),
            }

            info.update(
                {
                    "ego_id": str(item["ego_id"]),
                    "sender_id": str(item["sender_id"]),
                    "action_id": str(item["action_id"]),
                }
            )
            info["q_recv"] = float(item.get("q_recv", 0.0))
            info["quant_mode"] = str(item.get("quant_mode", ""))
            info["channel_state"] = str(item.get("channel_state", ""))
            info["redundancy_ratio"] = float(item.get("redundancy_ratio", 0.0))
            info["cache_enabled"] = float(item.get("cache_enabled", 0))
            info["cache_quality"] = float(item.get("cache_quality", 0.0))
            info["complementarity_raw"] = float(item.get("complementarity_raw", 0.0))
            info["complementarity_normalized"] = float(item.get("complementarity_normalized", 0.0))

            reward_infos.append(info)

        self.last_ego_confidence = float(ego_confidence)

        summary = {
            "collab_confidence": float(collab_confidence),
            "ego_confidence": float(ego_confidence),
            "delta_confidence": float(delta_conf),
            "num_updated": len(pending),
            "mean_reward": float(
                sum(x["reward"] for x in reward_infos) / max(len(reward_infos), 1)
            ),
            "link_rewards": reward_infos,
        }

        self._append_record({"reward_update": summary})
        return summary

    def get_records(self) -> List[Dict[str, Any]]:
        return copy.deepcopy(self.records)

    def get_frame_records(self, frame_id: Any) -> List[Dict[str, Any]]:
        return copy.deepcopy(self.frame_records.get(frame_id, []))

    def get_summary(self) -> Dict[str, Any]:
        total_tx = 0.0
        total_rx = 0.0
        selected = 0
        no_send = 0

        for r in self.records:
            if r.get("no_send", False):
                no_send += 1
            if r.get("dc2mab", {}).get("selected", False):
                selected += 1

            total_tx += float(
                r.get(
                    "actual_transmitted_bytes",
                    r.get("transmitted_bytes", r.get("tx_bytes", 0.0)),
                )
            )
            total_rx += float(
                r.get(
                    "actual_received_bytes",
                    r.get("received_bytes", r.get("rx_bytes", 0.0)),
                )
            )

        budget_source, budget_scope = self._budget_source_scope()

        return {
            "mode": "dc2mab",
            "num_records": int(len(self.records)),
            "num_selected_links": int(selected),
            "num_no_send_links": int(no_send),
            "total_transmitted_bytes": float(total_tx),
            "total_received_bytes": float(total_rx),
            "system_budget": {
                "budget_scope": str(budget_scope),
                "budget_source": str(budget_source),
                "system_budget_mbps": float(self.system_budget_mbps),
                "tx_window_ms": float(self.tx_window_ms),
                "system_budget_bytes": float(self._system_budget_bytes()),
            },
            "packetization": {
                "mode": "byte_stream",
                "quantize_first": True,
                "packet_size_bytes": int(self.packet_size_bytes),
            },
            "loss_model": {
                "type": "bernoulli",
                "good": 0.05,
                "medium": 0.20,
                "bad": 0.35,
            },
            "delay_model": {
                "type": "fixed_state_delay",
                "good": 10.0,
                "medium": 50.0,
                "bad": 100.0,
                "bad_temporal_source": "previous_frame",
            },
            "fec_redundancy": {
                "enabled": True,
                "rho_values": [0.0, 0.25, 0.5],
                "packet_cost": "encoded_packets = source_packets + ceil(source_packets * rho)",
            },
        }


__all__ = ["ARCEC2MABComm"]

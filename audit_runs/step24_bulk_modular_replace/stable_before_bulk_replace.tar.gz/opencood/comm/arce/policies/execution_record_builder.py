from __future__ import annotations

import copy
from typing import Any, Dict, Tuple


def _actual_tx_bytes(record: Dict[str, Any], fallback_cost_bytes: float) -> float:
    return float(
        record.get(
            "actual_transmitted_bytes",
            record.get(
                "transmitted_bytes",
                record.get("tx_bytes", fallback_cost_bytes),
            ),
        )
    )


def build_selected_execution_record(
    *,
    record: Dict[str, Any],
    selected: Any,
    pdf_action: Any,
    oracle_result: Dict[str, Any],
    total_budget_bytes: float,
    budget_scope: str,
    budget_source: str,
    system_budget_mbps: float,
    tx_window_ms: float,
    num_collaborators: int,
    per_link_budget_bytes: float,
    allocated_budget_bytes: float,
    link_budgets: Dict[int, float],
) -> Tuple[Dict[str, Any], float]:
    record = copy.deepcopy(record)

    record["dc2mab"] = {
        "selected": True,
        "proposal": selected.as_dict(),
        "oracle": {
            "budget_bytes": float(total_budget_bytes),
            "used_budget_bytes": float(oracle_result["used_budget_bytes"]),
            "remaining_budget_bytes": float(oracle_result["remaining_budget_bytes"]),
            "budget_scope": str(budget_scope),
            "budget_source": str(budget_source),
            "oracle_raw": {
                key: value
                for key, value in oracle_result.items()
                if key not in ("selected",)
            },
        },
    }

    record["pdf_action"] = pdf_action.as_dict()

    record["system_budget"] = {
        "budget_scope": str(budget_scope),
        "budget_source": str(budget_source),
        "system_budget_mbps": float(system_budget_mbps),
        "tx_window_ms": float(tx_window_ms),
        "system_budget_bytes": float(total_budget_bytes),
        "num_collaborators": int(num_collaborators),
        "per_link_budget_bytes": float(per_link_budget_bytes),
        "link_budget_bytes": float(
            selected.record.get("link_budget_bytes", per_link_budget_bytes)
        ),
        "proposal_budget_bytes": float(
            selected.record.get("proposal_budget_bytes", total_budget_bytes)
        ),
        "allocated_budget_bytes": float(allocated_budget_bytes),
        "link_budgets": {str(k): float(v) for k, v in link_budgets.items()},
    }

    tx_bytes = _actual_tx_bytes(record, fallback_cost_bytes=float(selected.cost_bytes))

    est = float(
        selected.record.get(
            "estimated_tx_bytes",
            selected.record.get("estimated_transmitted_bytes", 0.0),
        )
        or 0.0
    )
    allocated = float(allocated_budget_bytes or 0.0)
    actual = float(tx_bytes)

    record["budget_consistency"] = {
        "estimated_tx_bytes": float(est),
        "allocated_budget_bytes": float(allocated),
        "actual_tx_bytes": float(actual),
        "actual_over_est": float(actual / max(est, 1.0)),
        "actual_over_allocated": float(actual / max(allocated, 1.0)),
    }

    return record, float(tx_bytes)
